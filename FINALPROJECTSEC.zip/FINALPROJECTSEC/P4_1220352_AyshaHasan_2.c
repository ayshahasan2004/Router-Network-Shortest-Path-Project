#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define MAX_ROUTERS 20
#define INF INT_MAX
/////////////////////////////////////////////////
/*
aysha mohamad
sec 2
project 4
dr.radi jarrar
*/
///////////////////to make an array of structs to do the bfs
typedef struct {
    int visited;
    int cost;
    int path[MAX_ROUTERS];
    int pathLength;
    int vertex;
} Node;

////////////////////////// queue for BFS
typedef struct {
    Node queue[MAX_ROUTERS];
    int front;
    int rear;
} BFSQueue;
//////////initialize the queue
void initQueue(BFSQueue *q) {
    q->front = 0;
    q->rear = 0;
}

/////////check if the queue is empty
int isQueueEmpty(BFSQueue *q) {
    return q->front == q->rear;
}
////////////////////
///////////////////////struct for Min-Heap Node
struct MinHeapNode {
    int vertex;
    int cost;
};

///////////Min-Heap struct
struct MinHeap {
    int size;
    int capacity;
    int pos[MAX_ROUTERS];          ///////////position of each vertex in the heap
    struct MinHeapNode array[MAX_ROUTERS]; ////////heap array
};

///////////////DijkstraMatrix struct
struct DijkstraMatrix {
    char vertex;
    int known;
    int cost;
    char path[MAX_ROUTERS];
};
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////prototypes ////////////////////////
void enqueue(BFSQueue *q, Node node);
Node dequeue(BFSQueue *q);
int findRouterIndex(char routers[], char router, int routerCount);
char* bfs(int adjMatrix[MAX_ROUTERS][MAX_ROUTERS], char source, char destination, int routerCount) ;
void printAdjacencyMatrix(int adjMatrix[MAX_ROUTERS][MAX_ROUTERS], int routerCount, char routers[]);
int LoadFromFile(const char *filename, int adjMatrix[MAX_ROUTERS][MAX_ROUTERS], char routers[MAX_ROUTERS]);
char toUpperCase(char c);
struct MinHeap createMinHeap(int capacity);
void swapNodes(struct MinHeap *heap, int idx1, int idx2);
void minHeapify(struct MinHeap *heap, int idx);
struct MinHeapNode extractMin(struct MinHeap *heap);
void decreaseKey(struct MinHeap *heap, int v, int cost);
char* dijkstra(int src, int dest,int num_routers,char routers [MAX_ROUTERS] ,int adjMatrix[MAX_ROUTERS][MAX_ROUTERS]) ;
void menu();
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/////////enqueue a Node to the queue
void enqueue(BFSQueue *q, Node node) {
    if (q->rear < MAX_ROUTERS) {
        q->queue[q->rear++] = node;
    } else {
        printf("Queue overflow\n");
    }
}

////////dequeue a Node from the queue
Node dequeue(BFSQueue *q) {
    if (!isQueueEmpty(q)) {
        return q->queue[q->front++];
    } else {
        printf("Queue underflow\n");
        exit(EXIT_FAILURE);
    }
}

int findRouterIndex(char routers[], char router, int routerCount) {
    for (int i = 0; i < routerCount; i++) {
        if (routers[i] == router) {
            return i;
        }
    }
    return -1;
}
char* bfs(int adjMatrix[MAX_ROUTERS][MAX_ROUTERS], char source, char destination, int routerCount) {
    /////initialize nodes
    Node nodes[MAX_ROUTERS];///////array of structs
    for (int i = 0; i < routerCount; i++) {
        nodes[i].visited = 0;///// make all vertices as not visited
        nodes[i].cost = INF;//////make the cost for all vertices to inf
        nodes[i].pathLength = 0;//////// pathLength indicating how far it is from the source (how many nodes to reach the destination )
        nodes[i].vertex = i;//////////using int to simplifest the operation such as :accessing Matrix Elements
    }

    ////////////// build BFS queue
    BFSQueue q;
    initQueue(&q);

    ///////////////////////////////////convert source and destination characters to indices
    int sourceIndex = source - 'A';//////sub A because thats in upper case
    int destIndex = destination - 'A';

    /////////////////////////////////////////////////start BFS from the source
    nodes[sourceIndex].visited = 1;
    nodes[sourceIndex].cost = 0;
    nodes[sourceIndex].path[nodes[sourceIndex].pathLength++] = sourceIndex;//////////nodes[sourceIndex]:This accesses a node
                                                         ////// in the nodes array or list at the index sourceIndex.
                                                         /////////////nodes[sourceIndex].path:this refers to an array or list called path that is a property of the node ////
                                                         ////////at sourceIndex. The path is where the nodes are stored as part of a path
                                                         ////////nodes[sourceIndex].pathLength++:

                                                     /////////////// increments the pathLength property of the node at sourceIndex.
                                                     //////////////// post-increment operator (++) is used here. It first returns the current value of pathLength
                                                     ///////////(before incrementing) and then increments it.The increment indicates that a new node is being added to the path
    enqueue(&q, nodes[sourceIndex]);//////add the node to the q

    ////////////// BFS loop
    while (!isQueueEmpty(&q)) {
        Node current = dequeue(&q);///////take from the last element in q
        int currentVertex = current.vertex;////to find the vertex

        //////////if we reached the destination, stop
        if (currentVertex == destIndex) {
            printf("reach destination \n");
            break;
        }

        for (int i = 0; i < routerCount; i++) {
            if (adjMatrix[currentVertex][i] != INF && !nodes[i].visited) {
                nodes[i].visited = 1;
                nodes[i].cost = current.cost + adjMatrix[currentVertex][i];////// add the cost of the fist source
                nodes[i].pathLength = current.pathLength;///// setting the pathLength of node i to be the same as current.pathLength.

                // copy path from the current node
                for (int j = 0; j < current.pathLength; j++) {
                    nodes[i].path[j] = current.path[j];
                }
                nodes[i].path[nodes[i].pathLength++] = i;

                enqueue(&q, nodes[i]);
            }
        }
    }
    /*It explores the graph from a starting node (currentVertex).
For each node, it calculates the cost to reach neighboring nodes and updates the path.
It keeps track of the shortest path and the cost to reach each node.
Once the destination node is reached, it prints the cost and path to get there*/

    // print the path and cost to the destination
  // Build the path string
  // If destination is reached, construct and return the path
    if (nodes[destIndex].visited) {
        // Calculate required size for the path string
        int pathSize = nodes[destIndex].pathLength * 4 + 1; // "A -> B -> C" style path
        char* path = malloc(pathSize);////////allocate memory for the path
        if (!path) {//////if allocation failed
            printf("Memory allocation failed.\n");
            return NULL;
        }

        //////build the path string
        int pos = 0;
        for (int i = 0; i < nodes[destIndex].pathLength; i++) {
            if (i > 0) {
                path[pos++] = ' ';
                path[pos++] = '-';
                path[pos++] = '>';
                path[pos++] = ' ';
            }
            path[pos++] = 'A' + nodes[destIndex].path[i];////convert vertex index back to character
        }
        path[pos] = '\0'; // Null-terminate the string

        printf("Cost to %c: %d\n", destination, nodes[destIndex].cost);
        printf("Path to %c: %s\n", destination, path);

    return path;
} else {
    printf("No path to destination %c\n", destination);
    return NULL; // No path found
}
}
void printAdjacencyMatrix(int adjMatrix[MAX_ROUTERS][MAX_ROUTERS], int routerCount, char routers[]) {
    printf("Adjacency Matrix:\n    "); // Extra spacing for alignment

    ///////////////////////////// Print column headers (routers)
    for (int i = 0; i < routerCount; i++) {
        printf("%-4c", routers[i]); ////////////////////// Left-aligned, 4-character wide
    }
    printf("\n");

    //////////////////////////////////// print rows of the adjacency matrix
    for (int i = 0; i < routerCount; i++) {
        printf("%-4c", routers[i]); /////////row header (router name)
        for (int j = 0; j < routerCount; j++) {
            if (adjMatrix[i][j] == INF) {
                printf("%-4s", "INF"); /////////////// print "INF" for no connection
            } else {
                printf("%-4d", adjMatrix[i][j]); //////////////////////////// print the cost
            }
        }
        printf("\n");
    }
}

int LoadFromFile(const char *filename, int adjMatrix[MAX_ROUTERS][MAX_ROUTERS], char routers[MAX_ROUTERS]) {
    FILE *file;
    char line[50], from, to;
    int cost;
    int routerCount = 0;

    // initialize adjacency matrix with INF (no connection)
    for (int i = 0; i < MAX_ROUTERS; i++) {
        for (int j = 0; j < MAX_ROUTERS; j++) {
            adjMatrix[i][j] = INF;
        }
    }

    // Open the file
    file = fopen(filename, "r");
    if (file == NULL) {
        perror("Error opening file");
        return -1; ///////////// return error code
    }

    ///////////////////read the file and build the adjacency matrix
    while (fgets(line, sizeof(line), file)) {
        // ////////////use strtok to split the line into tokens based on '-'
        char *token = strtok(line, "-");
        if (token == NULL) continue;

        from = token[0]; ///////////////get the first token "router 1"

        token = strtok(NULL, "-");
        if (token == NULL) continue;
        to = token[0]; //////////// get the second token "router 2"

        token = strtok(NULL, "-");
        if (token == NULL) continue;
        cost = atoi(token); //////////////////////// convert the third token to  int (cost)

        ////////////////////////////////////// find or add routers
        int fromIndex = findRouterIndex(routers, from, routerCount);
        if (fromIndex == -1) {
            if (routerCount < MAX_ROUTERS) {
                routers[routerCount] = from;
                fromIndex = routerCount++;
            } else {
                printf("error:many router cannot add more\n");
                break;
            }
        }
/*this line checks if the destination router (to) is already in the routers array.
if found, toIndex will be the numeric index of the router in the array.
if not found (findRouterIndex returns -1), it means the router is not yet added to the array and must be added.*/
        int toIndex = findRouterIndex(routers, to, routerCount);
        if (toIndex == -1) {
            if (routerCount < MAX_ROUTERS) {
                routers[routerCount] = to;
                toIndex = routerCount++;
            } else {
                printf("error:many routers cannot add more\n");
                break;
            }
        }

        ////////// add cost to adjacency matrix (undirected)
        adjMatrix[fromIndex][toIndex] = cost;
        adjMatrix[toIndex][fromIndex] = cost;

    }

    fclose(file);
    return routerCount; /////////// return the number of routers
}
char toUpperCase(char c) {
    if (c >= 'a' && c <= 'z') {
        return c - 'a' + 'A';  //////convert lowercase to uppercase
    }
    return c;  /////////return the character as is if it not a lowercase letter
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
struct MinHeap createMinHeap(int capacity) {
    struct MinHeap heap;
    heap.size = 0;
    heap.capacity = capacity;
    for (int i = 0; i < MAX_ROUTERS; i++) {
        heap.pos[i] = -1; ///////////initialize positions as -1
    }
    return heap;
}
/////////////////////////////////////////////////////////////////////////////////////////
void swapNodes(struct MinHeap *heap, int idx1, int idx2) {
    struct MinHeapNode temp = heap->array[idx1];
    heap->array[idx1] = heap->array[idx2];
    heap->array[idx2] = temp;

    heap->pos[heap->array[idx1].vertex] = idx1;
    heap->pos[heap->array[idx2].vertex] = idx2;
}
/////////////////////////////////////////////////////////////////////////////////////////
void minHeapify(struct MinHeap *heap, int idx) {
    int smallest = idx;///root(parent)
    int left = 2 * idx + 1;
    int right = 2 * idx + 2;
    //////////must be the children :left ,right grater than root ==> root less than them

    if (left < heap->size && heap->array[left].cost < heap->array[smallest].cost)
        smallest = left;

    if (right < heap->size && heap->array[right].cost < heap->array[smallest].cost)
        smallest = right;

    if (smallest != idx) {
        swapNodes(heap, idx, smallest);
        minHeapify(heap, smallest);
    }
}
//////////////////////////////////////////////////////////////////////////////////////////
struct MinHeapNode extractMin(struct MinHeap *heap) {//// to remove and return the minimum element from the heap
    struct MinHeapNode root = heap->array[0];///////define the root to return it
    heap->array[0] = heap->array[heap->size - 1];

    heap->pos[heap->array[0].vertex] = 0;
    heap->pos[root.vertex] = -1;

    heap->size--;
    minHeapify(heap, 0);

    return root;
}
/////////////////////////////////////////////////////////////////////
void decreaseKey(struct MinHeap *heap, int v, int cost) {/////decrease the cost of the vertex
    int idx = heap->pos[v];
    heap->array[idx].cost = cost;

    while (idx && heap->array[idx].cost < heap->array[(idx - 1) / 2].cost) {
        swapNodes(heap, idx, (idx - 1) / 2);
        idx = (idx - 1) / 2;
    }
}

////////// Dijkstra /////////////////////////
char* dijkstra(int src, int dest, int num_routers, char routers[MAX_ROUTERS], int adjMatrix[MAX_ROUTERS][MAX_ROUTERS]) {
    struct DijkstraMatrix dMatrix[MAX_ROUTERS];
    char* resultPath = malloc(strlen(dMatrix[dest].path) + 1);

    ////////////////initialize Dijkstra Matrix
    for (int i = 0; i < num_routers; i++) {
        dMatrix[i].vertex = routers[i];
        dMatrix[i].known = 0;
        dMatrix[i].cost = INF;
        dMatrix[i].path[0] = '\0';  ///////////initialize path as empty
    }
    dMatrix[src].cost = 0;
    dMatrix[src].path[0] = routers[src];  ///////////set source path to the source router
    dMatrix[src].path[1] = '\0';          /////////////null terminate (empty path)

    ////////////create min-heap
    struct MinHeap heap = createMinHeap(num_routers);
    for (int i = 0; i < num_routers; i++) {
        heap.array[i].vertex = i;
        heap.array[i].cost = dMatrix[i].cost;
        heap.pos[i] = i;
    }
    heap.size = num_routers;

    decreaseKey(&heap, src, 0);

    while (heap.size) {
        struct MinHeapNode minNode = extractMin(&heap);
        int u = minNode.vertex;///////to determine the vertex

        dMatrix[u].known = 1;

        for (int v = 0; v < num_routers; v++) {
            if (adjMatrix[u][v] != INF && !dMatrix[v].known) {
                int newCost = dMatrix[u].cost + adjMatrix[u][v];

                if (newCost < dMatrix[v].cost) {//////if the new cost less than the orginal cost update the cost
                    dMatrix[v].cost = newCost;

                    /////////////copy path from u to v
                    int len = strlen(dMatrix[u].path);              ///////////length of current path
                    for (int i = 0; i < len; i++) {                //////////////copy characters
                        dMatrix[v].path[i] = dMatrix[u].path[i];
                    }
                    dMatrix[v].path[len] = ' ';                    ///////add ' '
                    dMatrix[v].path[len + 1] = '-';                /////////add '-'
                    dMatrix[v].path[len + 2] = '>';                /////add '>'
                    dMatrix[v].path[len + 3] = ' ';                ///////add ' '
                    ///////  -> char prevoius three lines work as this
                    dMatrix[v].path[len + 4] = routers[v];         //////add next router
                    dMatrix[v].path[len + 5] = '\0';               ///////null-terminate

                    decreaseKey(&heap, v, newCost);
                }
            }
        }
    }
    if (resultPath) {
    strcpy(resultPath, dMatrix[dest].path); ///////////copy the path to dynamically allocated memory
}

    //////////print shortest path and cost
    printf("Shortest path from %c to %c: %s\n", routers[src], routers[dest], dMatrix[dest].path);
    printf("Total cost: %d\n", dMatrix[dest].cost);
return resultPath; // Return the dynamically allocated memory
}
//////////////////////////////////////////////////////////////////////////////////////////////
void write_sequence_to_file(const char *filename,  char *sequence , char bfsordijk) {
    // Open the file in write mode ("w")
    FILE *outFile = fopen(filename, "a");

    // Check if file is opened successfully
    if (outFile == NULL) {
        printf("error opening file for writing.\n");
        return;
    }
    if (bfsordijk=='b'||bfsordijk=='B'){
         fprintf(outFile, "from bfs\n");
    // Write the sequence to the file using fprintf
    fprintf(outFile, "%s\n", sequence);
    }
    else{
         fprintf(outFile, "from dijkstra \n");
    // Write the sequence to the file using fprintf
    fprintf(outFile, "%s\n", sequence);
    }
    // Close the file after writing
    fclose(outFile);
}
/////////////////////////////////////////////////////////////////////////////////////////////////////
void menu(){
        printf("\n---------------------Router Menu--------------------------\n");
        printf("1. Load routers\n");
        printf("2. Enter source\n");
        printf("3. Enter destination and calculate shortest path\n");
        printf("4. save to output file --shortest_distance.txt--\n");
        printf("5. Exit\n");
}
////////////////////////////////////////////////////////////////////////////////////////////////////
int main() {
    char routers[MAX_ROUTERS]; ///////////array to store router names
    int adjMatrix[MAX_ROUTERS][MAX_ROUTERS]; //////////adjacency matrix
    int routerCount;
    const char *filename = "routers.txt";
    char *pathdijkstra,*pathbfs;
    char startRouter , endRouter;
    while (1) {
        menu();
        printf("Enter your choice: ");
        int choice;
        scanf("%d", &choice);
        getchar(); //////////newline character

        switch (choice) {
            case 1: {
                    routerCount = LoadFromFile(filename, adjMatrix, routers);
                     if (routerCount == -1) {
                          return 1; /////////exit if file loading failed
                       }
                    printf("Load done\n");
                    ////////////print the adjacency matrix
                    printAdjacencyMatrix(adjMatrix, routerCount, routers);
                    break;

            }
            case 2:
                {
                    printf("Enter the starting router: \n");
                    scanf("%c", &startRouter); ////////read the first character
                    getchar(); ////////consume the newline character left by scanf
                    startRouter = toUpperCase(startRouter); //////convert to uppercase
                    break;
                }
            case 3:
                {
                  printf("Enter the end router: \n");
                    scanf("%c", &endRouter); // Read the second character
                    getchar();
                    endRouter = toUpperCase(endRouter); // Convert to uppercase
                    printf("Starting Router: %c\n", startRouter);
                    printf("End Router: %c\n", endRouter);
                    // Convert character to indices
                    int srcIndex = findRouterIndex(routers, startRouter, routerCount);
                    int destIndex = findRouterIndex(routers, endRouter, routerCount);

                    if (srcIndex == -1 || destIndex == -1) {
                        printf("Invalid routers entered\n");
                        continue; // Stay in the loop if routers are invalid
                    }

                    pathbfs = bfs(adjMatrix, startRouter, endRouter, routerCount);
                    write_sequence_to_file("shortest_distance.txt", pathbfs, 'b');

                    pathdijkstra = dijkstra(srcIndex, destIndex, routerCount, routers, adjMatrix);
                    printf("%s", pathdijkstra);
                    write_sequence_to_file("shortest_distance.txt", pathdijkstra, 'd');
                    break;

                }
            case 4:
                {
                    printf("Exitinggggg the program :)\n");
                    break;
                }
        }
        if (choice ==4 || choice >4){
            printf("Exitinggggg the program :)\n");
            break;
        }
    }

     return 0;
    }


